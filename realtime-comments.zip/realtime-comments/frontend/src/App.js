import React, { useState, useEffect, useCallback, useRef } from 'react';
import socketService from './socketService';
import CommentItem from './components/CommentItem';
import CommentForm from './components/CommentForm';
import TypingIndicator from './components/TypingIndicator';
import './App.css';

function App() {
  const [comments, setComments] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [typingUsers, setTypingUsers] = useState([]);
  const [isConnected, setIsConnected] = useState(false);
  const [newCommentIds, setNewCommentIds] = useState(new Set());
  const commentsEndRef = useRef(null);

  const scrollToBottom = () => {
    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    // Connect to socket server
    const socket = socketService.connect();

    socket.on('connect', () => {
      setIsConnected(true);
      console.log('Connected to server');
    });

    socket.on('disconnect', () => {
      setIsConnected(false);
      console.log('Disconnected from server');
    });

    // Set up event listeners
    socketService.onInitialComments((initialComments) => {
      setComments(initialComments);
    });

    socketService.onCommentAdded((newComment) => {
      setComments(prev => [...prev, newComment]);
      setNewCommentIds(prev => new Set(Array.from(prev).concat(newComment.id)));
      // Remove the new comment highlight after 3 seconds
      setTimeout(() => {
        setNewCommentIds(prev => {
          const newSet = new Set(Array.from(prev));
          newSet.delete(newComment.id);
          return newSet;
        });
      }, 3000);
      // Auto scroll to new comment
      setTimeout(scrollToBottom, 100);
    });

    socketService.onUnreadCount((count) => {
      setUnreadCount(count);
    });

    socketService.onUserTyping((data) => {
      setTypingUsers(prev => {
        if (data.isTyping) {
          return prev.includes(data.user) ? prev : [...prev, data.user];
        } else {
          return prev.filter(user => user !== data.user);
        }
      });
    });

    // Cleanup on unmount
    return () => {
      socketService.removeAllListeners();
      socketService.disconnect();
    };
  }, []);

  const handleCommentSubmit = useCallback((author, text) => {
    socketService.sendComment(author, text);
  }, []);

  const handleCommentRead = useCallback((commentId) => {
    socketService.markCommentAsRead(commentId);
    // Update local state to mark comment as read
    setComments(prev => prev.map(comment => 
      comment.id === commentId ? { ...comment, isRead: true } : comment
    ));
  }, []);

  const handleTypingStart = useCallback((user) => {
    socketService.startTyping(user);
  }, []);

  const handleTypingStop = useCallback((user) => {
    socketService.stopTyping(user);
  }, []);

  return (
    <div className="App">
      <header className="app-header">
        <h1>Real-time Comments</h1>
        <div className="header-info">
          <div className={`connection-status ${isConnected ? 'connected' : 'disconnected'}`}>
            {isConnected ? '🟢 Connected' : '🔴 Disconnected'}
          </div>
          {unreadCount > 0 && (
            <div className="unread-badge">
              {unreadCount} unread comment{unreadCount > 1 ? 's' : ''}
            </div>
          )}
        </div>
      </header>

      <main className="app-main">
        <div className="comments-container">
          <h2>Discussion</h2>
          
          <div className="comments-list">
            {comments.length === 0 ? (
              <div className="no-comments">
                <p>No comments yet. Be the first to start the discussion!</p>
              </div>
            ) : (
              comments.map((comment) => (
                <CommentItem
                  key={comment.id}
                  comment={comment}
                  onRead={handleCommentRead}
                  isNew={newCommentIds.has(comment.id)}
                />
              ))
            )}
            <div ref={commentsEndRef} />
          </div>

          <TypingIndicator typingUsers={typingUsers} />

          <CommentForm 
            onSubmit={handleCommentSubmit}
            onTypingStart={handleTypingStart}
            onTypingStop={handleTypingStop}
          />
        </div>
      </main>
    </div>
  );
}

export default App;

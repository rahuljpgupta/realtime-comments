import { io, Socket } from 'socket.io-client';
import { Comment, TypingIndicator } from './types';

class SocketService {
  private socket: Socket | null = null;
  private userId: string;

  constructor() {
    this.userId = this.generateUserId();
  }

  private generateUserId(): string {
    return localStorage.getItem('userId') || this.createNewUserId();
  }

  private createNewUserId(): string {
    const newId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('userId', newId);
    return newId;
  }

  connect(serverUrl: string = 'http://localhost:3001'): Socket {
    if (this.socket) {
      return this.socket;
    }

    console.log('🔌 Attempting to connect to:', serverUrl);
    
    this.socket = io(serverUrl, {
      query: {
        userId: this.userId
      },
      transports: ['websocket', 'polling'] // Ensure fallback transport
    });

    // Add connection event listeners for debugging
    this.socket.on('connect', () => {
      console.log('✅ Connected to server with ID:', this.socket?.id);
    });

    this.socket.on('disconnect', (reason) => {
      console.log('❌ Disconnected from server. Reason:', reason);
    });

    this.socket.on('connect_error', (error) => {
      console.error('🚫 Connection error:', error);
    });

    return this.socket;
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  // Event listeners
  onInitialComments(callback: (comments: Comment[]) => void): void {
    this.socket?.on('initial_comments', callback);
  }

  onCommentAdded(callback: (comment: Comment) => void): void {
    this.socket?.on('comment_added', callback);
  }

  onUnreadCount(callback: (count: number) => void): void {
    this.socket?.on('unread_count', callback);
  }

  onUserTyping(callback: (data: TypingIndicator) => void): void {
    this.socket?.on('user_typing', callback);
  }

  // Event emitters
  sendComment(author: string, text: string): void {
    this.socket?.emit('new_comment', { author, text });
  }

  markCommentAsRead(commentId: string): void {
    this.socket?.emit('mark_comment_read', commentId);
  }

  startTyping(user: string): void {
    this.socket?.emit('typing_start', { user });
  }

  stopTyping(user: string): void {
    this.socket?.emit('typing_stop', { user });
  }

  getUserId(): string {
    return this.userId;
  }

  // Remove all listeners
  removeAllListeners(): void {
    this.socket?.removeAllListeners();
  }
}

export default new SocketService();

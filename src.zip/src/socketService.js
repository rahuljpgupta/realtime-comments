import { io } from 'socket.io-client';

class SocketService {
  constructor() {
    this.socket = null;
    this.userId = this.generateUserId();
  }

  generateUserId() {
    return localStorage.getItem('userId') || this.createNewUserId();
  }

  createNewUserId() {
    const newId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('userId', newId);
    return newId;
  }

  connect(serverUrl = 'http://localhost:3001') {
    if (this.socket) {
      return this.socket;
    }

    console.log('🔌 Attempting to connect to:', serverUrl);
    
    this.socket = io(serverUrl, {
      query: {
        userId: this.userId
      },
      transports: ['websocket', 'polling'] // Ensure fallback transport
    });

    // Add connection event listeners for debugging
    this.socket.on('connect', () => {
      console.log('✅ Connected to server with ID:', this.socket?.id);
    });

    this.socket.on('disconnect', (reason) => {
      console.log('❌ Disconnected from server. Reason:', reason);
    });

    this.socket.on('connect_error', (error) => {
      console.error('🚫 Connection error:', error);
    });

    return this.socket;
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  // Event listeners
  onInitialComments(callback) {
    this.socket?.on('initial_comments', callback);
  }

  onCommentAdded(callback) {
    this.socket?.on('comment_added', callback);
  }

  onUnreadCount(callback) {
    this.socket?.on('unread_count', callback);
  }

  onUserTyping(callback) {
    this.socket?.on('user_typing', callback);
  }

  // Event emitters
  sendComment(author, text) {
    this.socket?.emit('new_comment', { author, text });
  }

  markCommentAsRead(commentId) {
    this.socket?.emit('mark_comment_read', commentId);
  }

  startTyping(user) {
    this.socket?.emit('typing_start', { user });
  }

  stopTyping(user) {
    this.socket?.emit('typing_stop', { user });
  }

  getUserId() {
    return this.userId;
  }

  // Remove all listeners
  removeAllListeners() {
    this.socket?.removeAllListeners();
  }
}

export default new SocketService();

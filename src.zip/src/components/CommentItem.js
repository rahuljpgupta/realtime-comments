import React, { useEffect, useRef } from 'react';
import './CommentItem.css';

const CommentItem = ({ comment, onRead, isNew = false }) => {
  const commentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !comment.isRead) {
          // Mark as read when comment is visible
          onRead(comment.id);
        }
      },
      { threshold: 0.5 }
    );

    if (commentRef.current) {
      observer.observe(commentRef.current);
    }

    return () => {
      if (commentRef.current) {
        observer.unobserve(commentRef.current);
      }
    };
  }, [comment.id, comment.isRead, onRead]);

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) {
      return 'just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} minute${diffInMinutes > 1 ? 's' : ''} ago`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <div 
      ref={commentRef}
      className={`comment-item ${isNew ? 'comment-new' : ''} ${!comment.isRead ? 'comment-unread' : ''}`}
    >
      <div className="comment-header">
        <span className="comment-author">{comment.author}</span>
        <span className="comment-timestamp">{formatTimestamp(comment.timestamp)}</span>
        {!comment.isRead && <span className="unread-indicator">●</span>}
      </div>
      <div className="comment-text">{comment.text}</div>
    </div>
  );
};

export default CommentItem;

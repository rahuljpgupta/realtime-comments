// Simple connection test - add this to your React app temporarily for debugging

import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

const ConnectionTest = () => {
  const [status, setStatus] = useState('Connecting...');
  const [logs, setLogs] = useState([]);

  const addLog = (message) => {
    setLogs(prev => [...prev, `${new Date().toLocaleTimeString()}: ${message}`]);
  };

  useEffect(() => {
    addLog('Starting connection test...');
    
    const socket = io('http://localhost:3001', {
      transports: ['websocket', 'polling']
    });

    socket.on('connect', () => {
      setStatus('✅ Connected');
      addLog(`Connected with ID: ${socket.id}`);
    });

    socket.on('disconnect', (reason) => {
      setStatus('❌ Disconnected');
      addLog(`Disconnected: ${reason}`);
    });

    socket.on('connect_error', (error) => {
      setStatus('🚫 Connection Error');
      addLog(`Connection error: ${error.message}`);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div style={{ padding: '20px', border: '2px solid #ccc', margin: '20px' }}>
      <h3>🔧 Connection Test</h3>
      <p><strong>Status:</strong> {status}</p>
      <div>
        <strong>Logs:</strong>
        <div style={{ maxHeight: '200px', overflow: 'auto', backgroundColor: '#f5f5f5', padding: '10px', margin: '10px 0' }}>
          {logs.map((log, index) => (
            <div key={index} style={{ fontSize: '12px', fontFamily: 'monospace' }}>
              {log}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ConnectionTest;

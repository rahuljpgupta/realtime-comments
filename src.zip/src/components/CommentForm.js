import React, { useState, useRef, useEffect } from 'react';
import './CommentForm.css';

const CommentForm = ({ onSubmit, onTypingStart, onTypingStop }) => {
  const [author, setAuthor] = useState('');
  const [text, setText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Load author name from localStorage
    const savedAuthor = localStorage.getItem('authorName');
    if (savedAuthor) {
      setAuthor(savedAuthor);
    }
  }, []);

  const handleTextChange = (value) => {
    setText(value);

    if (author && value.trim()) {
      // Start typing indicator
      onTypingStart(author);

      // Clear existing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      // Stop typing after 2 seconds of inactivity
      typingTimeoutRef.current = setTimeout(() => {
        onTypingStop(author);
      }, 2000);
    } else if (author) {
      onTypingStop(author);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!author.trim() || !text.trim()) {
      return;
    }

    setIsSubmitting(true);

    // Stop typing indicator
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    onTypingStop(author);

    // Save author name to localStorage
    localStorage.setItem('authorName', author);

    // Submit comment
    onSubmit(author, text);

    // Clear form
    setText('');
    setIsSubmitting(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="comment-form">
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <input
            type="text"
            placeholder="Your name"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            className="author-input"
            required
          />
        </div>
        
        <div className="form-group">
          <textarea
            placeholder="Write a comment... (Cmd/Ctrl + Enter to submit)"
            value={text}
            onChange={(e) => handleTextChange(e.target.value)}
            onKeyDown={handleKeyDown}
            className="text-input"
            rows={4}
            required
            disabled={isSubmitting}
          />
        </div>
        
        <div className="form-actions">
          <button 
            type="submit" 
            disabled={!author.trim() || !text.trim() || isSubmitting}
            className="submit-button"
          >
            {isSubmitting ? 'Commenting...' : 'Comment'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CommentForm;
